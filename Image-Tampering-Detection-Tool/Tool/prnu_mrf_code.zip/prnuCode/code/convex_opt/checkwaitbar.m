function flag = checkwaitbar()
    flag = feature('ShowFigureWindows');